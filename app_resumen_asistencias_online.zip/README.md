# Resumen automatico de asistencias

Este programa permite seleccionar un Excel con el formato del listado de asistencia y genera otro Excel con:

- `Resumen`: agrupado por sede, fecha de actividad y actividad.
- `Detalle_clasificacion`: cada persona clasificada como `Asiste` o `No asiste`.

Regla usada:

- `Asiste`: la persona tiene al menos un `1` en las columnas `Clase 1`, `Clase 2`, `Clase 3`, `Clase 4`, etc.
- `No asiste`: la persona no tiene ningun `1`.
- `ausentes_0000`: conteo adicional de personas que tienen todas las clases en `0`.

## Como usarlo

### Opcion online

La app online usa el archivo `streamlit_app.py`.

1. Crea un repositorio en GitHub.
2. Sube estos archivos al repositorio:
   - `streamlit_app.py`
   - `app_resumen_asistencias.py`
   - `requirements.txt`
3. Entra a <https://share.streamlit.io/>.
4. Inicia sesion con GitHub.
5. Haz clic en `Create app`.
6. Selecciona el repositorio, la rama y como archivo principal escribe `streamlit_app.py`.
7. Haz clic en `Deploy`.
8. Cuando se abra la pagina, sube el Excel y descarga el resumen.

### Opcion local

1. Instala Python si no lo tienes.
2. Abre una terminal en esta carpeta.
3. Instala dependencias:

```powershell
pip install -r requirements.txt
```

4. Ejecuta:

```powershell
python app_resumen_asistencias.py
```

5. Selecciona el Excel.

El archivo resultante se guardara al lado del Excel original con el nombre terminado en `_RESUMEN.xlsx`.
